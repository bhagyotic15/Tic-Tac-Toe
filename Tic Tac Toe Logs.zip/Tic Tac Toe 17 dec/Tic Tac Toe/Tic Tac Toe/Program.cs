﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

class TicTacToeGame
{
    private char[,] TicTacToeBoard;
    private int currentPlayer;
    private int totalMoves;
    private string[] playerNames;

    public TicTacToeGame()
    {
        TicTacToeBoard = new char[,]
        {
            { '1', '2', '3' },
            { '4', '5', '6' },
            { '7', '8', '9' }
        };
        currentPlayer = 1;
        totalMoves = 0;
        playerNames = new string[2];
    }
  

    public void StartGame()
    {
        Console.WriteLine("Welcome to Tic Tac Toe Game! \n");
        Console.WriteLine("\n1.The game is played on a grid that's 3 squares by 3 squares.\n\n2.Player 1 is \"X\" and Player 2 is \"O\". Players take turns putting their marks in empty squares.\n\n3.The first player to get 3 of her marks in a row(horizontally, vertically or diagonally) is the winner.\n\n4.When all 9 squares are full, the game is over. If no player has 3 marks in a row, the game ends in a tie.\n\n5.You can put x or o in by typing the number you want to put it at");
        Console.ReadKey(false);
        Console.Clear();
        Console.WriteLine(" $Press Enter to start the game.$ ");
        Console.ReadLine();



    }

}
    class Program
    {
        static void Main()
        {
            TicTacToeGame game = new TicTacToeGame();
            game.StartGame();
        }
    }