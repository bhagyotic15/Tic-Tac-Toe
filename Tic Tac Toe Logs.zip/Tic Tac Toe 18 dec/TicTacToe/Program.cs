﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

class TicTacToeGame
{
    private char[,] TicTacToeBoard;
    private int currentPlayer;
    private int totalMoves;
    private string[] playerNames;
   



    public TicTacToeGame()
    {
        TicTacToeBoard = new char[,]
        {
            { '1', '2', '3' },
            { '4', '5', '6' },
            { '7', '8', '9' }
        };
        currentPlayer = 1;
        totalMoves = 0;
        playerNames = new string[2];
    }
    private void DisplayMenu()
    {
        Console.Clear();
        Console.WriteLine("\nChoose a game mode:");
        Console.WriteLine("1. Single Player (Player vs Computer)");
        Console.WriteLine("2. Duo Mode (Player vs Player)");
        Console.WriteLine("3. Exit");
    }

    private void SetGameMode(int choice)
    {
        Console.Clear();
        Console.WriteLine(choice == 1 ? "Single Player Mode" : "Duo Mode");
        Console.WriteLine("Press the corresponding keys to make a move on the TicTacToeBoard.");

        if (choice == 2)
        {
            Console.Write("Enter Player 1's name: ");
            playerNames[0] = Console.ReadLine();
            Console.Write("Enter Player 2's name: ");
            playerNames[1] = Console.ReadLine();
        }

        Console.WriteLine($"Player 1 (X) - {playerNames[0]} | Player 2 (O) - {playerNames[1]}\n");
    }



    private void DisplayTicTacToeBoard()
    {
        Console.Clear();
        Console.WriteLine($" {TicTacToeBoard[0, 0]} | {TicTacToeBoard[0, 1]} | {TicTacToeBoard[0, 2]} ");
        Console.WriteLine("-----------");
        Console.WriteLine($" {TicTacToeBoard[1, 0]} | {TicTacToeBoard[1, 1]} | {TicTacToeBoard[1, 2]} ");
        Console.WriteLine("-----------");
        Console.WriteLine($" {TicTacToeBoard[2, 0]} | {TicTacToeBoard[2, 1]} | {TicTacToeBoard[2, 2]} ");
        Console.WriteLine();
        Console.WriteLine($"Player {currentPlayer}'s turn ({playerNames[currentPlayer]}). Enter your move (1-9).");
    }


    public void StartGame()
    {
        Console.WriteLine("Welcome to Tic Tac Toe Game! \n");
        Console.WriteLine("\n1.The game is played on a grid that's 3 squares by 3 squares.\n\n2.Player 1 is \"X\" and Player 2 is \"O\". Players take turns putting their marks in empty squares.\n\n3.The first player to get 3 of her marks in a row(horizontally, vertically or diagonally) is the winner.\n\n4.When all 9 squares are full, the game is over. If no player has 3 marks in a row, the game ends in a tie.\n\n5.You can put x or o in by typing the number you want to put it at");
        Console.ReadKey(false);
        Console.Clear();
        Console.WriteLine(" $Press Enter to start the game.$ ");
        Console.ReadLine();

        while (true)
        {
            DisplayMenu();

            int choice;
            while (!int.TryParse(Console.ReadLine(), out choice) || choice < 1 || choice > 3)
            {
                Console.WriteLine("Invalid choice. Please enter a number between 1 and 3.");
            }

            if (choice == 3)
            {
                Console.WriteLine("Thank you for playing Tic Tac Toe!");
                break; // Exit the game
            }

        }

    }



    // Main Function 
    class Program
    {
        static void Main()
        {
            TicTacToeGame game = new TicTacToeGame();
            game.StartGame();
        }
    }
}